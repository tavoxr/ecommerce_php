-- MySQL dump 10.13  Distrib 8.0.25, for Linux (x86_64)
--
-- Host: localhost    Database: ecommerce_php
-- ------------------------------------------------------
-- Server version	8.0.25

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `files`
--

DROP TABLE IF EXISTS `files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `files` (
  `id` int NOT NULL AUTO_INCREMENT,
  `filename` varchar(250) NOT NULL,
  `filesize` int NOT NULL,
  `web_path` varchar(250) NOT NULL,
  `system_path` varchar(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `files`
--

LOCK TABLES `files` WRITE;
/*!40000 ALTER TABLE `files` DISABLE KEYS */;
INSERT INTO `files` VALUES (1,'1.jpg',1172703,'ecommerce_php/uploads/1.jpg','/var/www/htmlecommerce_php/uploads/1.jpg'),(2,'2.jpg',798875,'ecommerce_php/uploads/2.jpg','/var/www/htmlecommerce_php/uploads/2.jpg'),(3,'producto1.jpg',21000,'ecommerce_php/uploads/3.jpg','/var/www/htmlecommerce_php/uploads/3.jpg'),(4,'producto1.jpg',21000,'ecommerce_php/uploads/4.jpg','/var/www/htmlecommerce_php/uploads/4.jpg'),(5,'producto1.jpg',21000,'html/ecommerce_php/uploads/5.jpg','/var/www/htmlhtml/ecommerce_php/uploads/5.jpg'),(6,'producto1.jpg',21000,'/uploads/6.jpg','/var/www/html/uploads/6.jpg'),(7,'producto1.jpg',21000,'/ecommerce_php/uploads/7.jpg','/var/www/html/ecommerce_php/uploads/7.jpg'),(8,'ecommercePhp (3).png',64833,'/ecommerce_php/uploads/8.png','/var/www/html/ecommerce_php/uploads/8.png'),(9,'1.jpg',1172703,'/ecommerce_php/uploads/9.jpg','/var/www/html/ecommerce_php/uploads/9.jpg'),(10,'producto1.jpg',21000,'/ecommerce_php/uploads/10.jpg','/var/www/html/ecommerce_php/uploads/10.jpg'),(11,'producto1.jpg',21000,'/ecommerce_php/uploads/11.jpg','/var/www/html/ecommerce_php/uploads/11.jpg'),(12,'1.jpg',1172703,'/ecommerce_php/uploads/12.jpg','/var/www/html/ecommerce_php/uploads/12.jpg'),(13,'producto1.jpg',21000,'/ecommerce_php/uploads/13.jpg','/var/www/html/ecommerce_php/uploads/13.jpg'),(14,'1.jpg',1172703,'/ecommerce_php/uploads/14.jpg','/var/www/html/ecommerce_php/uploads/14.jpg'),(15,'1.jpg',1172703,'/ecommerce_php/uploads/15.jpg','/var/www/html/ecommerce_php/uploads/15.jpg'),(16,'aderezo.jpg',12732,'/ecommerce_php/uploads/16.jpg','/var/www/html/ecommerce_php/uploads/16.jpg'),(17,'leche.jpg',23506,'/ecommerce_php/uploads/17.jpg','/var/www/html/ecommerce_php/uploads/17.jpg'),(18,'mayonesa.jpg',17655,'/ecommerce_php/uploads/18.jpg','/var/www/html/ecommerce_php/uploads/18.jpg'),(19,'cheetos.jpg',23391,'/ecommerce_php/uploads/19.jpg','/var/www/html/ecommerce_php/uploads/19.jpg'),(20,'frijoles.jpg',22849,'/ecommerce_php/uploads/20.jpg','/var/www/html/ecommerce_php/uploads/20.jpg'),(21,'gomitas.jpg',36807,'/ecommerce_php/uploads/21.jpg','/var/www/html/ecommerce_php/uploads/21.jpg'),(22,'galletas.jpg',20289,'/ecommerce_php/uploads/22.jpg','/var/www/html/ecommerce_php/uploads/22.jpg'),(23,'leche.jpg',23506,'/ecommerce_php/uploads/23.jpg','/var/www/html/ecommerce_php/uploads/23.jpg'),(24,'aceite.jpg',11926,'/ecommerce_php/uploads/24.jpg','/var/www/html/ecommerce_php/uploads/24.jpg'),(25,'salsa.jpg',19398,'/ecommerce_php/uploads/25.jpg','/var/www/html/ecommerce_php/uploads/25.jpg'),(26,'cereal.jpg',62583,'/ecommerce_php/uploads/26.jpg','/var/www/html/ecommerce_php/uploads/26.jpg');
/*!40000 ALTER TABLE `files` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-06-02 15:40:29
